@echo off
echo Starting FB Marketplace Bot...
echo (Keep this window open. Press Ctrl+C to stop.)
echo.
python marketplace_bot.py
pause
