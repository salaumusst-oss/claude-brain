"""
Facebook Marketplace Tech Deal Bot
- Scans 65203 area (30 mile radius) for tech deals
- Sends push notifications via ntfy.sh within ~30 seconds of a new listing
"""

import asyncio
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

import httpx
from dotenv import load_dotenv
from playwright.async_api import async_playwright, Page, BrowserContext

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────
FB_EMAIL    = os.getenv("FB_EMAIL", "")
FB_PASSWORD = os.getenv("FB_PASSWORD", "")
NTFY_TOPIC  = os.getenv("NTFY_TOPIC", "fbmarket_bot_default")
NTFY_URL    = f"https://ntfy.sh/{NTFY_TOPIC}"

LOCATION    = "65203"
RADIUS_KM   = 48          # ~30 miles
POLL_SECS   = 30          # how often to re-scan each category
AUTH_FILE   = Path("fb_auth.json")
SEEN_FILE   = Path("seen_listings.json")

# Categories to watch (sorted newest first)
WATCH_URLS = [
    f"https://www.facebook.com/marketplace/{LOCATION}/electronics"
    f"?radius={RADIUS_KM}&sortBy=creation_time_descend",

    f"https://www.facebook.com/marketplace/{LOCATION}/computers-accessories"
    f"?radius={RADIUS_KM}&sortBy=creation_time_descend",

    f"https://www.facebook.com/marketplace/{LOCATION}/mobile-phones"
    f"?radius={RADIUS_KM}&sortBy=creation_time_descend",

    f"https://www.facebook.com/marketplace/{LOCATION}/video-games"
    f"?radius={RADIUS_KM}&sortBy=creation_time_descend",
]

# Keywords that qualify as "tech" (lowercased matching)
TECH_KEYWORDS = [
    "laptop", "macbook", "chromebook", "desktop", "pc", "computer", "imac",
    "mac mini", "mac pro", "monitor", "keyboard", "mouse",
    "iphone", "samsung", "pixel", "galaxy", "ipad", "tablet", "android",
    "gpu", "graphics card", "rtx", "gtx", "rx 6", "rx 7", "radeon",
    "cpu", "processor", "ram", "ssd", "hard drive", "hdd", "nvme",
    "motherboard", "psu", "power supply", "pc build", "gaming pc",
    "ps5", "ps4", "xbox", "nintendo", "switch", "playstation", "controller",
    "gaming", "console", "game",
    "apple", "airpods", "headphones", "earbuds", "beats",
    "camera", "gopro", "drone", "dji",
    "router", "modem", "nas", "server",
    "raspberry pi", "arduino", "smart home",
    "printer", "scanner", "projector", "tv", "television", "oled", "qled",
    "phone", "charger", "cable", "hub", "dock",
]

# ── Helpers ───────────────────────────────────────────────────────────────────

def load_seen() -> set:
    if SEEN_FILE.exists():
        return set(json.loads(SEEN_FILE.read_text()))
    return set()

def save_seen(seen: set):
    SEEN_FILE.write_text(json.dumps(list(seen)))

def is_tech(title: str) -> bool:
    t = title.lower()
    return any(kw in t for kw in TECH_KEYWORDS)

def log(msg: str):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)

async def send_notification(title: str, price: str, location: str, listing_url: str):
    message = f"💰 {price}  📍 {location}\n{listing_url}"
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                NTFY_URL,
                content=message.encode(),
                headers={
                    "Title": f"🔧 {title}",
                    "Priority": "high",
                    "Tags": "computer,iphone",
                    "Click": listing_url,
                },
            )
            if r.status_code == 200:
                log(f"  ✅ Notified: {title} — {price}")
            else:
                log(f"  ⚠️  ntfy returned {r.status_code}")
    except Exception as e:
        log(f"  ⚠️  Notification failed: {e}")

# ── Facebook login ─────────────────────────────────────────────────────────────

async def login(context: BrowserContext):
    page = await context.new_page()
    log("Logging into Facebook…")
    await page.goto("https://www.facebook.com/login", wait_until="domcontentloaded")
    await page.wait_for_timeout(2000)

    # Accept cookie dialog if present
    try:
        await page.click('[data-testid="cookie-policy-manage-dialog-accept-button"]', timeout=4000)
    except Exception:
        pass

    await page.fill("#email", FB_EMAIL)
    await page.fill("#pass", FB_PASSWORD)
    await page.click('[name="login"]')
    await page.wait_for_timeout(5000)

    # Check if we're still on login page (wrong credentials)
    if "login" in page.url and "checkpoint" not in page.url:
        log("❌ Login failed — check FB_EMAIL / FB_PASSWORD in .env")
        sys.exit(1)

    if "checkpoint" in page.url:
        log("⚠️  Facebook is asking for identity verification.")
        log("   Please complete the check in the browser window, then press Enter here.")
        input("   Press Enter once you've verified… ")
        await page.wait_for_timeout(3000)

    # Save auth state for future runs
    await context.storage_state(path=str(AUTH_FILE))
    log("✅ Logged in. Auth state saved.")
    await page.close()

# ── Scraping ──────────────────────────────────────────────────────────────────

LISTING_RE = re.compile(r"/marketplace/item/(\d+)/")

async def scrape_listings(page: Page, url: str) -> list[dict]:
    """Return list of {id, title, price, location, url} from a marketplace search page."""
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        await page.wait_for_timeout(3000)

        # Scroll a bit to trigger lazy-load
        await page.evaluate("window.scrollBy(0, 800)")
        await page.wait_for_timeout(1500)

    except Exception as e:
        log(f"  ⚠️  Page load error: {e}")
        return []

    listings = []
    seen_ids = set()

    # Find all marketplace item links
    anchors = await page.query_selector_all('a[href*="/marketplace/item/"]')

    for anchor in anchors:
        try:
            href = await anchor.get_attribute("href") or ""
            m = LISTING_RE.search(href)
            if not m:
                continue
            listing_id = m.group(1)
            if listing_id in seen_ids:
                continue
            seen_ids.add(listing_id)

            full_url = f"https://www.facebook.com/marketplace/item/{listing_id}/"

            # Get all text inside the card
            card_text = (await anchor.inner_text()).strip()
            lines = [ln.strip() for ln in card_text.splitlines() if ln.strip()]

            title    = lines[0] if lines else "Unknown"
            price    = next((l for l in lines if "$" in l), "Price unknown")
            location = lines[-1] if len(lines) > 1 else ""

            listings.append({
                "id":       listing_id,
                "title":    title,
                "price":    price,
                "location": location,
                "url":      full_url,
            })
        except Exception:
            continue

    return listings

# ── Main loop ─────────────────────────────────────────────────────────────────

async def main():
    if not FB_EMAIL or not FB_PASSWORD:
        print("❌ Set FB_EMAIL and FB_PASSWORD in your .env file first.")
        sys.exit(1)

    if NTFY_TOPIC == "fbmarket_bot_default":
        print("⚠️  Using default ntfy topic — set a unique NTFY_TOPIC in .env")

    log(f"Starting FB Marketplace bot for zip {LOCATION} ({RADIUS_KM}km / 30mi radius)")
    log(f"Notifications → ntfy.sh/{NTFY_TOPIC}")
    log(f"Polling every {POLL_SECS}s across {len(WATCH_URLS)} categories")

    seen = load_seen()

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=False)  # visible so you can solve CAPTCHAs

        # Load saved auth or do fresh login
        if AUTH_FILE.exists():
            context = await browser.new_context(storage_state=str(AUTH_FILE))
            log("Loaded saved auth state.")
        else:
            context = await browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                )
            )
            await login(context)

        page = await context.new_page()

        # ── First run: populate seen set without notifying ──────────────────
        log("First pass: loading existing listings (no notifications)…")
        for url in WATCH_URLS:
            initial = await scrape_listings(page, url)
            for item in initial:
                seen.add(item["id"])
            log(f"  Seeded {len(initial)} listings from {url.split('/')[-2]}")
        save_seen(seen)
        log(f"✅ Ready. Watching for NEW listings now.\n")

        # ── Polling loop ────────────────────────────────────────────────────
        while True:
            for url in WATCH_URLS:
                listings = await scrape_listings(page, url)
                new_count = 0

                for item in listings:
                    if item["id"] in seen:
                        continue

                    seen.add(item["id"])
                    new_count += 1

                    if is_tech(item["title"]):
                        log(f"🆕 NEW TECH: {item['title']} — {item['price']}")
                        await send_notification(
                            title=item["title"],
                            price=item["price"],
                            location=item["location"],
                            listing_url=item["url"],
                        )
                    else:
                        log(f"   (skipped non-tech: {item['title']})")

                if new_count:
                    save_seen(seen)

            log(f"Scan complete. Next scan in {POLL_SECS}s…")
            await asyncio.sleep(POLL_SECS)


if __name__ == "__main__":
    asyncio.run(main())
