@echo off
echo ============================================
echo  FB Marketplace Bot - First Time Setup
echo ============================================
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause
    exit /b 1
)

echo [1/3] Installing Python dependencies...
pip install -r requirements.txt
if errorlevel 1 ( echo Install failed. & pause & exit /b 1 )

echo.
echo [2/3] Installing Playwright browsers...
python -m playwright install chromium
if errorlevel 1 ( echo Playwright install failed. & pause & exit /b 1 )

echo.
echo [3/3] Setting up .env config...
if not exist .env (
    copy .env.example .env
    echo.
    echo *** IMPORTANT: Open .env in Notepad and fill in your details ***
    echo.
    notepad .env
) else (
    echo .env already exists, skipping.
)

echo.
echo ============================================
echo  Setup complete! Run start.bat to launch.
echo ============================================
pause
