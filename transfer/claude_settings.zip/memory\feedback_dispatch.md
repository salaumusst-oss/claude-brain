---
name: feedback-dispatch
description: Always use the claude-brain dispatch system to split work between PC and MacBook when the other machine is online
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 20d74af2-3028-4af0-90ba-5badad5ee124
---

Always check if the MacBook is online at the start of complex tasks and use the dispatch system to split work.

**Why:** User confirmed they want the two-machine brain system used — MacBook should handle research/planning while PC handles building/output.

**How to apply:** At the start of any multi-step task (research, lead gen, analysis, builds), run `check-online.ps1` first. If MacBook is online, use `dispatch.ps1` to split the work. Don't do everything solo on the PC when the Mac is available.
