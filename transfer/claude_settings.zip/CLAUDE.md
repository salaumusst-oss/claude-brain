# Global Claude Code Instructions

## Shared Brain
This machine is connected to the Claude Brain system.
- Brain directory: `C:\Users\musst\claude-brain\`
- Read `C:\Users\musst\claude-brain\CLAUDE.md` at the start of any session
- Shared memory lives in `C:\Users\musst\claude-brain\memory\`
- Sync with: `powershell -File C:\Users\musst\claude-brain\sync.ps1`

At the start of each session:
1. Pull latest brain: `git -C C:\Users\musst\claude-brain pull`
2. Check handoff: read `C:\Users\musst\claude-brain\handoff\current.md`
3. Check inbox: list `C:\Users\musst\claude-brain\inbox\`
