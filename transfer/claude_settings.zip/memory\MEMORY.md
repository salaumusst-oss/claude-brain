# Memory Index

- [Claude Brain Setup](brain_setup.md) — shared brain system across PC and laptop via GitHub
- [Use Dispatch System](feedback_dispatch.md) — always split work between PC and MacBook using dispatch.ps1 when Mac is online
