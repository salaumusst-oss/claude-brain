---
name: brain-setup
description: Shared Claude Code brain system connecting PC and laptop via GitHub repo
metadata: 
  node_type: memory
  type: project
  originSessionId: f6fdace1-b222-41c0-abd6-366380e663a3
---

Shared brain repo: https://github.com/salaumusst-oss/claude-brain.git
Local path (PC): C:\Users\musst\claude-brain\

**Why:** User wants to continue work seamlessly between PC and laptop, and have two Claude Code instances collaborate on tasks.

**How to apply:** When starting a session, check C:\Users\musst\claude-brain\handoff\current.md for context from the other machine. Write handoffs there when switching. Memory files in claude-brain/memory/ are the source of truth across machines. Sync script runs automatically on Stop hook.
